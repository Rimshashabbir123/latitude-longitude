import React, { useState } from 'react';

const Cards = () => {
  const [apiData, setApiData] = useState([]);

  const fetchData = () => {
    fetch('https://dummyjson.com/products/category/womens-dresses')
      .then((res) => res.json())
      .then((data) => {
        // صرف پہلے 6 products کو set کریں
        setApiData(data.products.slice(0, 6));
      })
      .catch((error) => console.error('Error fetching data:', error));
  };

  return (
    <section className="container py-5" id="portfolio">
      <h1 className="text-center font-bold mb-10 text-3xl">New Collections</h1>

      <div className="text-center mb-6">
        <button
          onClick={fetchData}
          className="btn btn-primary"
        >
          Fetch Data
        </button>
        <br />
      </div>
              <br />
        <br />


      <div className="row">
        {apiData.map((item) => (
          <div key={item.id} className="col-md-4 mb-4">
            <div className="card h-100">
              <img
                src={item.thumbnail}
                className="card-img-top"
                alt={item.title}
                style={{ height: '200px', objectFit: 'cover' }}
              />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{item.title}</h5>
                <p className="card-text flex-grow-1">{item.description}</p>
                <p className="text-success fw-bold">${item.price}</p>
                <a href="#" className="btn btn-primary mt-auto">
                  Buy Now
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Cards;
