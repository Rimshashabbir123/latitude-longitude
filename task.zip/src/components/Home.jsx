// components/Home.js
import React from 'react';

const Home = () => {
  return (
    <section className="text-center py-10 bg-gray-100">
      <h2 className="text-4xl font-bold mb-4">Welcome to Our Collection</h2>
      <p className="text-lg text-gray-700">
        Explore our stunning new range of women’s dresses, fashion, and more.
      </p>
    </section>
  );
};

export default Home;
